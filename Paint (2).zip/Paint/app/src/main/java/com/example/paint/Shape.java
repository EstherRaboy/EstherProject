package com.example.paint;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public abstract class Shape {
    protected int x;
    protected int y;
    protected String color;
    protected int lineWidth;

    public Shape(int x, int y, String color) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.lineWidth= 5;
    }

    public abstract void updatePoint(int xe,int ye);

    public void draw(Canvas canvas, Paint paint)
    {
        paint.setColor(Color.parseColor(color));
        paint.setStrokeWidth(lineWidth);
    }

    protected Double calculArea(){
        return 1.0;
    }
}