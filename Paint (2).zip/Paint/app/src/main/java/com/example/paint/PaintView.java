package com.example.paint;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Region;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class PaintView extends View {

    public static Paint paint;
    private Paint bgPaint;
    private String currentShape = "Rect";
    private String currentColor = "#FFFFFFFF";
    private List<Path> paths = new ArrayList<Path>();
    private Stack<Shape> shapes;
    private int lineWidth;
    private boolean fillShape = false;

    private Path path= new Path();


    public PaintView(Context context) {
        super(context);
        shapes = new Stack<>();
        paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        bgPaint = new Paint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(12);
        bgPaint.setColor(Color.rgb(255,255,255));
    }


    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPaint(bgPaint);
        for (int i = 0; i < shapes.size(); i++)
            shapes.get(i).draw(canvas, paint);
    }

    Shape shape;
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            if(currentShape.equals("Rect"))
            {
                shape = new RectShape((int)event.getX(),(int)event.getY(),currentColor);
                ((RectShape)shape).setFill(this.fillShape);
            }
            else if(currentShape.equals("Circle"))
            {
                shape = new CircleShape((int)event.getX(),(int)event.getY(),currentColor);
                ((CircleShape)shape).setFill(this.fillShape);
            }
            else if(currentShape.equals("Line"))
            {
                shape = new LineShape((int)event.getX(),(int)event.getY(),currentColor);
            }
            else if(currentShape.equals("Path")){
                shape = new PathShape((int)event.getX(),(int)event.getY(),currentColor);

            }
            shape.lineWidth= this.lineWidth;
            shapes.push(shape);
            invalidate();
        }
        if(event.getAction() == MotionEvent.ACTION_MOVE)
        {
            shape.updatePoint((int)event.getX(),(int)event.getY());
            invalidate();
        }
        return true;
    }

    public void addLine() {
        currentShape = "Line";
    }

    public void addRect() {
        currentShape = "Rect";
    }

    public void addCircle() {
        currentShape = "Circle";
    }

    public void addPath() {
        currentShape = "Path";
    }

    public void setColor(String color)
    {
        currentColor = color;
    }

    public void setLineWidth(int w){
        lineWidth= w;
    }

    public void undo() {
        if (!shapes.isEmpty()) {
            shapes.pop();
            invalidate();
        }
    }
    public void clearPath(){
            Stack<Shape> copy= new Stack<Shape>();
            Shape tmp;
            while(shapes.isEmpty() == false)
            {
                tmp = shapes.pop();
                //if(!(tmp instanceof PathShape))
                if(tmp.getClass() != PathShape.class)
                {
                    copy.push(tmp);
                }
            }
            while (!copy.isEmpty())
            {
                tmp = copy.pop();
                shapes.push(tmp);
            }
            invalidate();
    }

    public void clearAll()
    {
            shapes.clear();
            invalidate();
    }

    public void setFill()
    {
        fillShape = !fillShape;
    }

   public boolean maxShapeRemain() {
       Shape tmp;
       Shape maxAreaShape = null;
       Stack<Shape> copy= new Stack<Shape>();
       double maxArea = 0.0;
       boolean noAreas= false;
       while (!shapes.isEmpty()) {
           tmp = shapes.pop();
           if ((tmp instanceof Shape2D)) {
               double area = tmp.calculArea();
               if (area > maxArea) {
                   maxArea = area;
                   maxAreaShape = tmp;
               }
           }
           copy.push(tmp);
       }
       if(maxAreaShape!=null) {
           shapes.push(maxAreaShape);
       }
       else{
           noAreas= true;
       }
       invalidate();
       return noAreas;
   }

    public Bitmap getBitmap()
    {
        this.setDrawingCacheEnabled(true);
        this.buildDrawingCache();
        Bitmap bmp = Bitmap.createBitmap(this.getDrawingCache());
        this.setDrawingCacheEnabled(false);

        return bmp;
    }

    public boolean bitIsEmpty(){
        Bitmap bmp = Bitmap.createBitmap(this.getDrawingCache());
        Bitmap emptyBitmap = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), bmp.getConfig());
        if (!bmp.sameAs(emptyBitmap)) {
            return false;
        }
        return true;
    }
}
