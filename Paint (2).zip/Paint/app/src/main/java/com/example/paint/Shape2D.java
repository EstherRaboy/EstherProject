package com.example.paint;

public class Shape2D extends Shape{

    private double area;

    public Shape2D(int x, int y, String color) {
        super(x, y, color);
    }


    @Override
    public void updatePoint(int xe, int ye) {

    }

    protected Double calculArea(){
        return 1.0;
    }
}
