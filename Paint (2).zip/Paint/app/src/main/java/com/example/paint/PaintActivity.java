package com.example.paint;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import top.defaults.colorpicker.ColorPickerPopup;

public class PaintActivity extends AppCompatActivity {
    private static final String TAG = "PaintActivity";
    private FrameLayout frame;
    private PaintView paintView;
    private SeekBar seekBar;
    private TextView txtWidth;
    private int mDefaultColor;
    private View mColorPreview;
    private static String fileName;
    private Button btnCP;
    File path= new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/myArt");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paint);
        frame = findViewById(R.id.frm);
        paintView = new PaintView(this);
        frame.addView(paintView);
        Button btnClear= (Button) findViewById(R.id.btnPoint);
        Button btnColor= (Button) findViewById(R.id.btnBlue);
        seekBar= (SeekBar) findViewById(R.id.LineWidth);
        txtWidth= (TextView) findViewById(R.id.txtWidth);
        btnCP= (Button) findViewById(R.id.btnCP);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtWidth.setText(i+"dp");
                paintView.setLineWidth(i);
                seekBar.setMax(50);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }


        });

        btnClear.setOnLongClickListener(new Button.OnLongClickListener() {

                            public boolean onLongClick (View V){
                                paintView.clearPath();
                                return true;
                            }

                        }
        );

        askPermission();


        SimpleDateFormat format= new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        String date= format.format(new Date());
        fileName= path+ "/" + date +".jpeg";

        if(!path.exists()){
            path.mkdir();
        }
    }

    private void askPermission() {
        Dexter.withContext(this).withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE).withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                Toast.makeText(PaintActivity.this, "granted!", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();
    }

    public void saveImg() throws IOException {

            File file = new File(fileName);

            Bitmap bitmap = paintView.getBitmap();

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 0, bos);

            byte[] bitmapData = bos.toByteArray();
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bitmapData);
            fos.flush();
            fos.close();

        Toast.makeText(PaintActivity.this, "success!", Toast.LENGTH_SHORT).show();
    }

    public void savePNG(View view){
            try{
                saveImg();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

    public void addLine(View view) {
        paintView.addLine();
    }
    public void addRect(View view) {
        paintView.addRect();
    }
    public void addPath(View view) {
        paintView.addPath();
    }
    public void addCircle(View view) {
        paintView.addCircle();
    }
    public void clearPath(View view) {
        paintView.clearPath();
    }
    public void maxShapeRemain(View view){
        if(paintView.maxShapeRemain()==true){
            Toast.makeText(this,"No area shapes", Toast.LENGTH_SHORT).show();
        }
    }

    public void changeColor(View view)
    {
        String color = view.getTag().toString();
        paintView.setColor(color);
    }

    public void setPickedColor(int color){
        String hex = Integer.toHexString(color);
        paintView.setColor("#"+hex);
    }
    
    public void clear(View view) {
        paintView.undo();
    }

    public void fillChange(View view)
    {
        paintView.setFill();
    }


    public void PickColor(View v){
        new ColorPickerPopup.Builder(this)
                .initialColor(Color.RED) // Set initial color
                .enableBrightness(true) // Enable brightness slider or not
                .enableAlpha(true) // Enable alpha slider or not
                .okTitle("Choose")
                .cancelTitle("Cancel")
                .showIndicator(true)
                .showValue(true)
                .build()
                .show(v, new ColorPickerPopup.ColorPickerObserver() {
                    @Override
                    public void onColorPicked(int color) {
                        v.setBackgroundColor(color);
                        setPickedColor(color);
                    }
                });

    }


}
